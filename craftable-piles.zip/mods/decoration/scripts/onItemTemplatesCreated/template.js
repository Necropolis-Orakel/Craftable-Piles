var ItemTemplateBuilder = Packages.org.gotti.wurmunlimited.modsupport.ItemTemplateBuilder;
var ItemTypes = Packages.com.wurmonline.server.items.ItemTypes;
var logger = Packages.java.util.logging.Logger.getLogger("nekropolis.deco");



function onItemTemplatesCreated() {
	
	//----------------------------
	//     Korb mit Mais
	//----------------------------
	
	var maiskorb = new ItemTemplateBuilder("nekropolis.deco.maiskorb");
	maiskorb.name("Maiskorb", "Maiskorb", "Maiskorb");
	maiskorb.descriptions("excellent", "good", "ok", "poor");
	maiskorb.itemTypes([ 
		ItemTypes.ITEM_TYPE_WOOD,
		ItemTypes.ITEM_TYPE_NAMED,
		ItemTypes.ITEM_TYPE_OWNER_DESTROYABLE,
		ItemTypes.ITEM_TYPE_DESTROYABLE,
		ItemTypes.ITEM_TYPE_TURNABLE,
		ItemTypes.ITEM_TYPE_REPAIRABLE,
		ItemTypes.ITEM_TYPE_COLORABLE,
		ItemTypes.ITEM_TYPE_MISSION,
		ItemTypes.ITEM_TYPE_DECORATION,
		ItemTypes.ITEM_TYPE_HASDATA,
		ItemTypes.ITEM_TYPE_NORENAME,
		ItemTypes.ITEM_TYPE_PLANTABLE
			]);
	maiskorb.imageNumber(542);
	maiskorb.behaviourType(41);
	maiskorb.combatDamage(0);
	maiskorb.decayTime(9072000);
	maiskorb.dimensions(10, 30, 60);
	maiskorb.primarySkill(-10);
	maiskorb.bodySpaces(Packages.com.wurmonline.server.MiscConstants.EMPTY_BYTE_PRIMITIVE_ARRAY);
	maiskorb.modelName("nekropolis.deco.maiskorb.");
	maiskorb.difficulty(10.0);
	maiskorb.weightGrams(500);
	maiskorb.material(14);
	maiskorb.isTraded(true);
	var templatemaiskorb = maiskorb.build();
	logger.info("Created item template " + templatemaiskorb.getTemplateId() + " for Maiskorb");
	

}

