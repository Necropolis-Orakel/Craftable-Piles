var IdFactory = Packages.org.gotti.wurmunlimited.modsupport.IdFactory;
var IdType = Packages.org.gotti.wurmunlimited.modsupport.IdType;
var CreationCategories = Packages.com.wurmonline.server.items.CreationCategories;
var ItemList = Packages.com.wurmonline.server.items.ItemList;
var SkillList = Packages.com.wurmonline.server.skills.SkillList;
var CreationEntryCreator = Packages.com.wurmonline.server.items.CreationEntryCreator;
var logger = Packages.java.util.logging.Logger.getLogger("nekropolis.deco");
var CreationRequirement = Packages.com.wurmonline.server.items.CreationRequirement;

function onServerStarted() {
	
	//----------------------------
	//     Deco Maiskorb
	//----------------------------
	
	var maiskorb = IdFactory.getIdFor("nekropolis.deco.maiskorb", IdType.ITEMTEMPLATE);
	var maiskorb_recipe = CreationEntryCreator.createAdvancedEntry(SkillList.CARPENTRY_FINE, ItemList.shaft, ItemList.plank, maiskorb, false, false, 0.0 , true, true, 0, 10.0, CreationCategories.FURNITURE);
	    maiskorb_recipe.addRequirement(new CreationRequirement(1, ItemList.plank, 2, true));
        maiskorb_recipe.addRequirement(new CreationRequirement(2, ItemList.shaft, 2, true));
        maiskorb_recipe.addRequirement(new CreationRequirement(3, ItemList.clothYard, 1, true));
	logger.info("Created creation entry for Maiskorb");

}